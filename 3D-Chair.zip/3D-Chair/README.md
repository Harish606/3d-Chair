# 3D-Chair-Configurator

Simple demo using three.js to configure a 3D chair model
<br><br>
Original chair model by <a href="https://www.blendswap.com/blends/view/72073" target="_blank">sensenku</a>
